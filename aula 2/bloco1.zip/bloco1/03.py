number1 = int(input('Digite o primeiro número: '))
number2 = int(input('Digite o segundo número: '))
numberSum = number1 + number2
print('A soma é ' + str(numberSum))