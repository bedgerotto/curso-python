import math

raio = float(input('Digite p raio do círculo: '))
area = (math.pi * (raio ** 2))
print('area: ' + str(area))