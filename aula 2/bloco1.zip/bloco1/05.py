metros = float(input('Digite a media em metros: '))
centimetros = metros * 100
print(str(centimetros) + ' centimetros')