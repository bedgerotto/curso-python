altura = float(input('Digite a altura do quadrado: '))
largura = float(input('Digite a largura do quadrado: '))

area = (altura * largura)
print('area: ' + str(area * 2))