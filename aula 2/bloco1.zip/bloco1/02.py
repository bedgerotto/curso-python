number = input('Digite um número: ')
print('O número digitado foi ' + number)