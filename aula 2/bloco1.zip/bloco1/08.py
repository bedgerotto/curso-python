valor = float(input('Digite o valor por hora: '))
horas = float(input('Digite quantas horas por dia trabalha: '))

mensal = (valor * horas * 30)
print('Seu salário é: ' + str(mensal))