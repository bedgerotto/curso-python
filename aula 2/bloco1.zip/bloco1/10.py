celsius = float(input('Digite a temperatura em graus Farenheit: '))

farenheit = (1.8 * celsius + 32)
print('A temperatura em graus Celsius é: ' + str(farenheit) + '°')