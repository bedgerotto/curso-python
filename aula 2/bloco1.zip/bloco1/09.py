farenheit = float(input('Digite a temperatura em graus Farenheit: '))

celsius = (5 * (farenheit - 32) / 9)
print('A temperatura em graus Celsius é: ' + str(celsius) + '°')