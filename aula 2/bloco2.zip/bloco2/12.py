n1 = float(input('Digite um número (negativo ou positivo): '))
cardinalidade = 'Positivo' if n1 > 0  else 'Negativo'
print('O número é: ' + str(cardinalidade))