n1 = float(input('Digite um número: '))
n2 = float(input('Digite outro número: '))
maior = n1 if n1 > n2 else n2
print('O maior é: ' + str(maior))